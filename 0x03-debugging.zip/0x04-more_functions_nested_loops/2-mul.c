#include "main.h"
/**
 * mul -  checks for checks for a digit (0 through 9).
 * @a: a -  Variable
 * @b: b - variable
 * Return: Always 0.
 */
int mul(int a, int b)
{
	int mul;

	mul = a * b;

	return (mul);
}
