#include "main.h"
int _atoi(char *s)
{}
