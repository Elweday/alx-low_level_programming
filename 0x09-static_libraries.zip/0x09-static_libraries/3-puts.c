#include "main.h"
void _puts(char *str)
{}	
