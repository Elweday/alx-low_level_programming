#include "main.h"
int _isdigit(int c)
{}	
