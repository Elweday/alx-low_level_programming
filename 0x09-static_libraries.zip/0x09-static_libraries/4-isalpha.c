#include "main.h"
int _isalpha(int c)
{}
