#include "main.h"
int _strcmp(char *s1, char *s2)
{}
