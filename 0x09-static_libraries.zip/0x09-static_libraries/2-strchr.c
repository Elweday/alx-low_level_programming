#include "main.h"
char *_strchr(char *s, char c)
{}
