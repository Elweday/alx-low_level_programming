#include "main.h"
char *_strstr(char *haystack, char *needle)
{}
