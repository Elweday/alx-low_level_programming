#include "main.h"
int _strlen(char *s)
{}
